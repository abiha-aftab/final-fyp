package com.example.fyp_screens;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.example.fyp_screens.R;

import java.util.ArrayList;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.MyViewHolder> {

    Context context;
    ArrayList<user_history> data;
    LayoutInflater inflater;

    public AdapterClass(Context context, ArrayList<user_history> data) {
        this.context=context;
        this.data=data;
        inflater= LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int position){
        View view= inflater.inflate(R.layout.activity_recycler,parent,false);
        MyViewHolder holder= new MyViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int position){
        user_history p= data.get(position);
        myViewHolder.textview1.setText(p.text);
        myViewHolder.textview2.setText(p.result1);
        myViewHolder.textview3.setText(p.result2);
    }
    @Override
    public int getItemCount(){
        // System.out.print(getdata.size());
        return data.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView textview1;
        TextView textview2;
        TextView textview3;

        public MyViewHolder(View itemview)
        {
            super(itemview);
            itemview.setOnClickListener(this);
            context = itemview.getContext();
            textview1= (TextView) itemview.findViewById(R.id.tv1);
            textview2= (TextView) itemview.findViewById(R.id.tv2);
            textview3= (TextView) itemview.findViewById(R.id.tv3);
        }

        @Override
        public void onClick(View v) {

        }
    }
}
