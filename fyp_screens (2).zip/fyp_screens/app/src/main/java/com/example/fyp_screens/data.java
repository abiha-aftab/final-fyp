package com.example.fyp_screens;

import com.example.fyp_screens.R;

import java.util.ArrayList;


public class data {


    public static ArrayList<user_history> getData() {

        ArrayList<user_history> data = new ArrayList<>();

      String[] emails= {"abihaaftab@gmail.com","munta@gmail.com","arshia@gmail.com","munta@gmail.com","munta@gmail.com","munta@gmail.com","munta@gmail.com","munta@gmail.com","munta@gmail.com","munta@gmail.com"};
      String[] text= {"How you doing","get off you bitch","Trump is a culprit","The box has stuff in it","I hate everyone","John is very dear friend","Get me some ice cream","He is a stupid boy"};
        String[] result1= {"Not Offensive","Offensive","Offensive","Not Offensive","Offensive", "Not Offensive", "Not Offensive", "Offensive"};
        String[] result2= {"Untargeted","Targeted","Targeted","Untargeted","Untargeted","Untargeted","Untargeted","Targeted"};

        for (int i = 0; i < text.length; i++) {

            user_history current = new user_history();
            current.email = emails[i];
            current.text = text[i];
            current.result1=result1[i];
            current.result2=result2[i];
            data.add(current);
        }

        return data;
    }

}