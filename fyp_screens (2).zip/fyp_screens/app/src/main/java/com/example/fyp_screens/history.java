package com.example.fyp_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;


import java.util.ArrayList;

public class history extends AppCompatActivity {

    RecyclerView recycle;
    AdapterClass adapt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
         recycle= (RecyclerView) findViewById(R.id.recyclerViewDemo);
         adapt = new AdapterClass(this,data.getData());
         recycle.setAdapter(adapt);
         recycle.setLayoutManager(new LinearLayoutManager(this));


    }
}
