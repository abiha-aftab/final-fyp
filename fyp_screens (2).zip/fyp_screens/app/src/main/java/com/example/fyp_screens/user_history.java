package com.example.fyp_screens;

public class user_history {
    String email;
    String text;
    String result1; //offensive and non-offensive
    String result2; //untargetted and targeted

    String getEmail(){
        return email;
    }
    String gettext(){
        return text;
    }
    String getresult1(){
        return result1;
    }
    String getresult2(){
        return result2;
    }

}
